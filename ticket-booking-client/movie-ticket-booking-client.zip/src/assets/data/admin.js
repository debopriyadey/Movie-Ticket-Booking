export const admin = {
    userId: "admin",
    password: "1234"
} 